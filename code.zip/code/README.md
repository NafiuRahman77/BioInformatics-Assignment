# BioInformatics-Assignment

Modified Gibbs Sampler selects the sequence which has the worst motif (logic is we check by removing each motif sequence in loop; after removing a motif, motif score is calculated. If motif score decrease is highest, then that motif is surely worst, so select that sequence) for each iteration. Other than that, its similar to Gibbs Sampler.
